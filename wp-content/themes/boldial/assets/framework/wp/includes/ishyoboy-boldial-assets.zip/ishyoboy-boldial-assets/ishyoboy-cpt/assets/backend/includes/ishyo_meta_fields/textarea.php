<textarea name="<?php echo $id?>" id="<?php echo $id?>" rows="5" cols="50" class="regular-text"><?php echo $value?></textarea>
